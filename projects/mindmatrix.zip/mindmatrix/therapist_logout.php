<?php
session_start();

// Unset all session variables
session_unset();

// Destroy the session
session_destroy();

// Redirect to the therapist login page
header("Location: login_therapist.php");
exit();
?>
