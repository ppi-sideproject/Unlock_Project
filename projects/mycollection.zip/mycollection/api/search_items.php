<?php
include("../config.php");
header("Content-Type: application/json");

$q = $_GET['query'] ?? "";

$query = "SELECT * FROM items WHERE title LIKE '%$q%' OR description LIKE '%$q%'";
$result = $conn->query($query);

$data = [];
while ($row = $result->fetch_assoc()) {
    $data[] = $row;
}

echo json_encode(["status" => "success", "items" => $data]);
?>