<?php


header('Content-Type: application/json');
include("../config.php"); 

$response = ["status" => "error", "message" => "Invalid request."];


if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['id'], $_POST['title'], $_POST['description'], $_POST['tag_id'])) {
    
    
    $id = $conn->real_escape_string($_POST['id']);
    $title = trim($conn->real_escape_string($_POST['title']));
    $description = $conn->real_escape_string($_POST['description']);
    $tag_id = $conn->real_escape_string($_POST['tag_id']);
    $image_url = $conn->real_escape_string($_POST['image_url'] ?? '');
    $link_url = $conn->real_escape_string($_POST['link_url'] ?? '');

   
    $duplicate_check_sql = "SELECT id FROM items WHERE title = '$title' AND id != '$id'";
    $duplicate_result = $conn->query($duplicate_check_sql);

    if ($duplicate_result->num_rows > 0) {
        $response = [
            "status" => "error", 
            "message" => "The title **'{$title}'** already exists for another item. Please choose a unique title."
        ];
    } else {
        
        $update_sql = "UPDATE items SET 
            title = '$title', 
            description = '$description', 
            tag_id = '$tag_id', 
            image_url = '$image_url', 
            link_url = '$link_url' 
            WHERE id = '$id'";

        if ($conn->query($update_sql) === TRUE) {
            if ($conn->affected_rows > 0) {
                $response = [
                    "status" => "success", 
                    "message" => "Item **'{$title}'** updated successfully!"
                ];
            } else {
               
                $response = [
                    "status" => "info", 
                    "message" => "No changes detected for item **'{$title}'**."
                ];
            }
        } else {
            $response = [
                "status" => "error", 
                "message" => "Database Error: " . $conn->error
            ];
        }
    }
}


$conn->close();
echo json_encode($response);
?>