<?php
include("../config.php");

header("Content-Type: application/json");;

if (!isset($_POST['id'])) {
    echo json_encode(["status" => "error", "message" => "Item ID is required"]);
    exit;
}

$id = intval($_POST['id']);
if ($id <= 0) {
     echo json_encode(["status" => "error", "message" => "Invalid Item ID"]);
     exit;
}

$sql = "DELETE FROM items WHERE id = $id";

if (mysqli_query($conn, $sql)) {
    echo json_encode(["status" => "success", "message" => "Item deleted successfully!"]);
} else {
    echo json_encode(["status" => "error", "message" => "Database error: " . mysqli_error($conn)]);
}