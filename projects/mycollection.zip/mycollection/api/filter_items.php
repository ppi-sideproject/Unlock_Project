<?php
header("Content-Type: application/json");
include "../config.php";

if(!isset($_GET['tag_id'])){
    echo json_encode(["status" => false, "message" => "Tag ID required"]);
    exit;
}

$tag_id = intval($_GET['tag_id']);

$sql = "SELECT items.id, items.title, items.description, items.image_url, items.link_url, tags.tag_name
        FROM items
        LEFT JOIN tags ON items.tag_id = tags.id
        WHERE items.tag_id = $tag_id";

$result = $conn->query($sql);

if($result){
    $data = [];
    while($row = $result->fetch_assoc()){ $data[] = $row; }

    if(count($data) > 0){
        echo json_encode(["status" => true, "items" => $data]);
    } else {
        echo json_encode(["status" => false, "message" => "No items found for this tag"]);
    }
} else {
    echo json_encode(["status" => false, "message" => "Filter query failed"]);
}