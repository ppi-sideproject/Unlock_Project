<?php
include("../config.php");
header("Content-Type: application/json");

$query = "SELECT * FROM tags";
$result = $conn->query($query);

$data = [];
while ($row = $result->fetch_assoc()) {
    $data[] = $row;
}

echo json_encode(["status" => "success", "tags" => $data]);
?>