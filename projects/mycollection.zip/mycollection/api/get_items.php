<?php
include("../config.php");
header("Content-Type: application/json");

$query = "SELECT items.*, tags.tag_name 
          FROM items 
          JOIN tags ON items.tag_id = tags.id";

$result = $conn->query($query);

$data = [];

while ($row = $result->fetch_assoc()) {
    $data[] = $row;
}

echo json_encode(["status" => "success", "items" => $data]);
?>