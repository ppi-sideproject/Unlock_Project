<?php
include("../config.php");

header("Content-Type: application/json");

if($_SERVER['REQUEST_METHOD'] !== "POST"){
    echo json_encode(["status"=>"error","message"=>"Invalid Request"]);
    exit;
}

$title = $_POST['title'] ?? '';
$description = $_POST['description'] ?? '';
$tag_id = $_POST['tag_id'] ?? '';
$image_url = $_POST['image_url'] ?? '';
$link_url = $_POST['link_url'] ?? '';

if(empty($title) || empty($description) || empty($tag_id)){
    echo json_encode(["status"=>"error","message"=>"Missing Required Fields"]);
    exit;
}

if($image_url == ""){
    $image_url = "https://via.placeholder.com/150?text=No+Image";
}

$query = "INSERT INTO items (title, description, image_url, link_url, tag_id) 
          VALUES ('$title','$description','$image_url','$link_url','$tag_id')";

if(mysqli_query($conn, $query)){
    echo json_encode(["status"=>"success", "message"=>"Item added successfully"]);
} else {
    echo json_encode(["status"=>"error","message"=>"DB Insert failed"]);
}
?>