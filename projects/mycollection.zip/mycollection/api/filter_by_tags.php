
<?php
include "../config.php";

header("Content-Type: application/json");

if(!isset($_GET['tag_id'])){
    echo json_encode(["status" => "error", "message" => "tag_id is required"]);
    exit;
}

$tag_id = $_GET['tag_id'];

$sql = "SELECT items.*, tags.tag_name 
        FROM items 
        JOIN tags ON items.tag_id = tags.id 
        WHERE tag_id = '$tag_id'";

$result = mysqli_query($conn, $sql);

$data = [];

while($row = mysqli_fetch_assoc($result)){
    $data[] = $row;
}

echo json_encode(["status" => "success", "data" => $data]);
?>