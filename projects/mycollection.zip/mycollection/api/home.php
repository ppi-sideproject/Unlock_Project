<?php include("config.php"); ?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>My Collection Manager</title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

<style>
    body { background-color: #c6dff0ff; }
    .fab {
        position: fixed; 
        bottom: 30px; 
        right: 30px;
        width: 50px; height: 50px; border-radius: 50%;
        font-size: 30px; line-height: 30px; text-align: center;
        box-shadow: 0 4px 12px rgba(0,24 , 161, 0.2);
        z-index: 100; 
    }
    .item-card { border: 1px solid #c5bae4; border-radius: 25px; overflow: hidden; }
    .item-image { width: 150px; height: 150px; object-fit: cover; }
</style>

</head>
<body>
<div class="container py-4">

    <div class="row mb-4">
        <div class="col-12">
            <h1 class="mb-3">My Collection</h1>

            <form method="GET" class="d-flex justify-content-between align-items-center">
                <div class="input-group w-50 me-3">
                    <span class="input-group-text bg-white border-end-0">🔍</span>
                    <input type="text" name="search" class="form-control border-start-0" placeholder="Search items..." value="<?php echo $_GET['search'] ?? '' ?>">
                </div>

                <select name="tag" class="form-select w-auto">
                    <option value="">All Tags</option>
                    <?php 
                        $tags = $conn->query("SELECT * FROM tags");
                        while($t = $tags->fetch_assoc()){
                            $selected = ($_GET['tag'] ?? '') == $t['id'] ? "selected" : "";
                            echo "<option value='{$t['id']}' $selected>{$t['tag_name']}</option>";
                        }
                    ?>
                </select>

                
            </form>
        </div>
    </div>

    <div class="row g-3">
        <?php
            $where = "WHERE 1";

            if(!empty($_GET['search'])){
                $s = $_GET['search'];
                $where .= " AND (title LIKE '%$s%' OR description LIKE '%$s%')";
            }

            if(!empty($_GET['tag'])){
                $tag = $_GET['tag'];
                $where .= " AND tag_id='$tag'";
            }

            $items = $conn->query("SELECT items.*, tags.tag_name FROM items JOIN tags ON items.tag_id = tags.id $where");

            if($items->num_rows > 0){
                while($row = $items->fetch_assoc()){
                    echo "
                    <div class='col-12'>
                        <div class='d-flex bg-white p-3 shadow-sm item-card'>
                            <img src='{$row['image_url']}' class='img-fluid me-3 item-image'>
                            <div class='flex-grow-1'>
                                <div class='d-flex justify-content-between align-items-start'>
                                    <h5 class='mb-1'>{$row['title']}</h5>
                                    <span class='badge bg-primary text-white'>{$row['tag_name']}</span>
                                </div>
                                <p class='text-muted mb-3'>{$row['description']}</p>
                                <div class='d-flex justify-content-end align-items-center'>
                                    <a href='{$row['link_url']}' target='_blank' class='btn btn-outline-primary btn-sm me-2'>Visit</a>
                                    <button class='btn btn-outline-secondary btn-sm me-1'>✏️</button>
                                    <button class='btn btn-outline-danger btn-sm'>🗑️</button>
                                    
                                </div>
                            </div>
                        </div>
                    </div>
                    ";
                }
        
            } else {
                echo "<p class='text-center text-danger'>No items found</p>";
            }
        ?>
    </div>
</div>

<a href="add_item.php" class="btn btn-primary fab">+</a>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>


<?php include("config.php"); ?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>My Collection Manager</title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

<style>
    body 
    { background-color: #f4f7faff; }
    .fab {
        position: fixed; 
        bottom: 30px; 
        right: 30px;
        width: 50px; 
        height: 50px; 
        border-radius: 50%;
        font-size: 30px; 
        line-height: 30px; 
        text-align: center;
        box-shadow: 0 4px 12px rgba(232, 234, 243, 0.2);
        z-index: 100; 
    }
    .item-card 
    { border: 1px solid #c5bae4; 
      border-radius: 25px; 
      overflow: hidden; }
    .item-image
     { width: 150px; 
       height: 150px; 
       object-fit: cover; }
</style>

</head>
<body>
<div class="container py-4">

    <div class="row mb-4">
        <div class="col-12">
            <h1 class="mb-3">My Collection</h1>

            <form method="GET" class="d-flex justify-content-between align-items-center">
                <div class="input-group w-50 me-3">
                    <span class="input-group-text bg-white border-end-0">🔍</span>
                    <input type="text" name="search" class="form-control border-start-0" placeholder="Search items..." value="<?php echo $_GET['search'] ?? '' ?>">
                </div>

                <select name="tag" class="form-select w-auto">
                    <option value="">All Tags</option>
                    <?php 
                        $tags = $conn->query("SELECT * FROM tags");
                        while($t = $tags->fetch_assoc()){
                            $selected = ($_GET['tag'] ?? '') == $t['id'] ? "selected" : "";
                            echo "<option value='{$t['id']}' $selected>{$t['tag_name']}</option>";
                        }

                    ?>
                </select>
            </form>
        </div>
    </div>

    <div class="row g-3">
        <?php
            $where = "WHERE 1";

            if(!empty($_GET['search']))
                {
                $s = $_GET['search'];
                $where .= " AND (title LIKE '%$s%' OR description LIKE '%$s%')";
            }

            if(!empty($_GET['tag'])){
                $tag = $_GET['tag'];
                $where .= " AND tag_id='$tag'";
            }

            $items = $conn->query("SELECT items.*, tags.tag_name FROM items JOIN tags ON items.tag_id = tags.id $where");

            if($items->num_rows > 0){
                while($row = $items->fetch_assoc()){
                    echo "
                    <div class='col-12'>
                        <div class='d-flex bg-white p-3 shadow-sm item-card'>
                            <img src='{$row['image_url']}' class='img-fluid me-3 item-image'>
                            <div class='flex-grow-1'>
                                <div class='d-flex justify-content-between align-items-start'>
                                    <h5 class='mb-1'>{$row['title']}</h5>
                                    <span class='badge bg-primary text-white'>{$row['tag_name']}</span>
                                </div>
                                <p class='text-muted mb-3'>{$row['description']}</p>
                                <div class='d-flex justify-content-end align-items-center'>
                                    <a href='{$row['link_url']}' target='_blank' class='btn btn-outline-primary btn-sm me-2'>Visit</a>
                                    <button class='btn btn-outline-secondary btn-sm me-1'>✏️</button>
                                    <button class='btn btn-outline-danger btn-sm'>🗑️</button>
 
                                </div>
                            </div>
                        </div>
                    </div>
                    ";
                }
            } 
            else 
                {
                echo "<p class='text-center text-danger'>No items found</p>";
            }
        ?>
    </div>
</div>

<a href="add_item.php" class="btn btn-primary fab">+</a>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>

<?php include("config.php"); ?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>My Collection Manager</title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

<style>
    body 
    { background-color: #f4f7faff; }
    .fab {
        position: fixed; 
        bottom: 30px; 
        right: 30px;
        width: 50px; 
        height: 50px; 
        border-radius: 50%;
        font-size: 30px; 
        line-height: 30px; 
        text-align: center;
        box-shadow: 0 4px 12px rgba(232, 234, 243, 0.2);
        z-index: 100; 
    }
    .item-card 
    { border: 1px solid #c5bae4; 
      border-radius: 25px; 
      overflow: hidden; }
    .item-image
     { width: 150px; 
       height: 150px; 
       object-fit: cover; }
</style>

</head>
<body>
<div class="container py-4">

    <div class="row mb-4">
        <div class="col-12">
            <h1 class="mb-3">My Collection</h1>

            <form method="GET" class="d-flex justify-content-between align-items-center">
                <div class="input-group w-50 me-3">
                    <span class="input-group-text bg-white border-end-0">🔍</span>
                    <input type="text" name="search" class="form-control border-start-0" placeholder="Search items..." value="<?php echo $_GET['search'] ?? '' ?>">
                </div>

                <select name="tag" class="form-select w-auto">
                    <option value="">All Tags</option>
                    <?php 
                        $tags = $conn->query("SELECT * FROM tags");
                        while($t = $tags->fetch_assoc()){
                            $selected = ($_GET['tag'] ?? '') == $t['id'] ? "selected" : "";
                            echo "<option value='{$t['id']}' $selected>{$t['tag_name']}</option>";
                        }

                    ?>
                </select>
            </form>
        </div>
    </div>

    <div class="row g-3">
        <?php
            $where = "WHERE 1";

            if(!empty($_GET['search']))
                {
                $s = $_GET['search'];
                $where .= " AND (title LIKE '%$s%' OR description LIKE '%$s%')";
            }

            if(!empty($_GET['tag'])){
                $tag = $_GET['tag'];
                $where .= " AND tag_id='$tag'";
            }

            $items = $conn->query("SELECT items.*, tags.tag_name FROM items JOIN tags ON items.tag_id = tags.id $where");

            if($items->num_rows > 0){
                while($row = $items->fetch_assoc()){
                    echo "
                    <div class='col-12'>
                        <div class='d-flex bg-white p-3 shadow-sm item-card'>
                            <img src='{$row['image_url']}' class='img-fluid me-3 item-image'>
                            <div class='flex-grow-1'>
                                <div class='d-flex justify-content-between align-items-start'>
                                    <h5 class='mb-1'>{$row['title']}</h5>
                                    <span class='badge bg-primary text-white'>{$row['tag_name']}</span>
                                </div>
                                <p class='text-muted mb-3'>{$row['description']}</p>
                                <div class='d-flex justify-content-end align-items-center'>
                                    <a href='{$row['link_url']}' target='_blank' class='btn btn-outline-primary btn-sm me-2'>Visit</a>
                                    <button class='btn btn-outline-secondary btn-sm me-1'>✏️</button>
                                    <button class='btn btn-outline-danger btn-sm'>🗑️</button>
 
                                </div>
                            </div>
                        </div>
                    </div>
                    ";
                }
            } 
            else 
                {
                echo "<p class='text-center text-danger'>No items found</p>";
            }
        ?>
    </div>
</div>

<a href="add_item.php" class="btn btn-primary fab">+</a>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>





