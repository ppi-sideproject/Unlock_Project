
<?php
include("../config.php");
header("Content-Type: application/json");

$id = $_GET['id'] ?? "";

$query = "SELECT * FROM items WHERE id='$id'";
$result = $conn->query($query);

if ($result->num_rows == 1) {
    echo json_encode(["status" => "success", "item" => $result->fetch_assoc()]);
} else {
    echo json_encode(["status" => "error", "message" => "Item not found"]);
}
?>