<?php

include "config.php";

$default_image_url = 'default_img.png'; 


header('Content-Type: application/json');


$response = ['status' => 'error', 'message' => 'Invalid request method.'];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    
    
    if (empty($_POST['title']) || empty($_POST['description']) || empty($_POST['tag_id'])) {
        $response['message'] = 'Error: Required fields are missing.';
        echo json_encode($response);
        exit;
    }
    
    $title = mysqli_real_escape_string($conn, $_POST['title']);
    $description = mysqli_real_escape_string($conn, $_POST['description']);
    $tag_id = intval($_POST['tag_id']); 
    
    $submitted_image_url = $_POST['image_url'] ?? '';
    $link_url = mysqli_real_escape_string($conn, $_POST['link_url'] ?? '');

    
   
    if (empty(trim($submitted_image_url))) {
        $image_url_to_save = $default_image_url;
    } else {
        $image_url_to_save = mysqli_real_escape_string($conn, $submitted_image_url);
    }

    
   
    $check_query = "SELECT id FROM items WHERE title='$title' LIMIT 1";
    $check_result = $conn->query($check_query);

    if ($check_result->num_rows > 0) {
     
        $response['message'] = "Item with the title '{$title}' already exists! Please use a different title.";
        echo json_encode($response);
        exit;
    }

    
    
    $insert_query = "INSERT INTO items (title, description, tag_id, image_url, link_url)
                     VALUES ('$title', '$description', '$tag_id', '$image_url_to_save', '$link_url')";

    if ($conn->query($insert_query)) {
        $response['status'] = 'success';
        $response['message'] = "Item Added Successfully!";
    } else {
        $response['message'] = "Error: Could not save item. " . $conn->error;
    }
}


echo json_encode($response);
exit;

?>