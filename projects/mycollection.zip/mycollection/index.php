<?php 

include("config.php"); 


$tags_result = $conn->query("SELECT * FROM tags");
$all_tags = [];
while($t = $tags_result->fetch_assoc()){
    $all_tags[] = $t;
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8"> 
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>My Collection</title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" rel="stylesheet" />

<style>
    
   
    :root {
        /* Light Mode */
        --bg-main: linear-gradient(135deg, #fdfbff, #f4f0ff);
        --bg-card: rgba(255, 255, 255, 0.7);
        --text-primary: #4a3f70;
        --text-muted: #6c757d;
        --card-border: rgba(180, 176, 215, 0.4);
        --card-shadow-hover: 0 8px 20px rgba(150, 130, 255, 0.2);
        --input-bg: white;
    }

    /* Dark Mode */
    .dark-mode {
        --bg-main: #1f1d2b;
        --bg-card: #2c293d;
        --text-primary: #e0e0e0;
        --text-muted: #b0b0b0;
        --card-border: rgba(200, 200, 255, 0.1);
        --card-shadow-hover: 0 8px 20px rgba(0, 0, 0, 0.5);
        --input-bg: #3c3954;
    }
    
    
    
    .dark-mode .bg-white {
        background-color: var(--bg-card) !important;
    }
    .dark-mode .text-muted {
        color: var(--text-muted) !important;
    }
    .dark-mode .form-control, 
    .dark-mode .form-select,
    .dark-mode .input-group-text {
        background-color: var(--input-bg) !important;
        color: var(--text-primary) !important;
        border-color: var(--card-border) !important;
    }
    .dark-mode .form-control::placeholder {
        color: var(--text-muted);
    }
    .dark-mode h1 {
        color: var(--text-primary) !important;
    }
   

    body {
        background: var(--bg-main);
        font-family: 'Poppins', sans-serif;
        color: var(--text-primary); 
        transition: background-color 0.3s, color 0.3s;
    }

    h1 {
        font-weight: 700;
        color: var(--text-primary);
        transition: color 0.3s;
    }

    .modal-dialog {
        max-width: 1000px;
    }
    
    
   
    #darkModeToggle {
        width: 40px;
        height: 40px;
        border-radius: 50%;
        font-size: 18px;
        line-height: 40px;
        background: #4a3f70;
        border: none;
        color: white;
        box-shadow: 0 3px 10px rgba(0, 0, 0, 0.1);
        cursor: pointer;
        transition: 0.3s ease;
        padding: 0; 
        text-align: center;
        margin-left: 15px; 
        flex-shrink: 0;
    }
    #darkModeToggle:hover {
        transform: scale(1.05);
        background: #5b4f85;
    }
    
   
    .fab {
        position: fixed;
        bottom: 30px;
        right: 30px;
        width: 75px;
        height: 75px;
        border-radius: 80%;
        font-size: 45px;
        text-align: center;
        line-height: 60px;
        background: #6a4cff;
        border: none;
        box-shadow: 0 10px 25px rgba(106, 76, 255, 0.4);
        color: white;
        transition: 0.3s ease;
        z-index: 1000;
    }
    .fab:hover {
        background: #5336d3;
        transform: scale(1.08);
    }

    .item-card {
        border-radius: 25px;
        background: var(--bg-card); 
        backdrop-filter: blur(10px);
        border: 2px solid var(--card-border); 
        transition: 0.3s ease;
    }
    .item-card:hover {
        transform: translateY(-4px);
        box-shadow: var(--card-shadow-hover); 
    }

    .item-image {
        width: 160px;
        height: 160px;
        border-radius: 18px;
        object-fit: cover;
        box-shadow: 0 4px 10px rgba(0,0,0,0.18);
    }

    .badge {
        background: #6a4cff !important;
        padding: 7px 12px;
        border-radius: 20px;
        font-size: 13px;
    }

    .btn-outline-secondary {
        border-radius: 20px;
        color: #6a4cff;
        border-color: #6a4cff;
    }
    .btn-outline-secondary:hover {
        background: #6a4cff;
        color: white;
    }

    .visit-btn-long {
        min-width: 80px; 
        border-radius: 12px;
    }

    .modal-content {
        border-radius: 20px;
        background: var(--input-bg); 
        border: none;
        box-shadow: 0 5px 25px rgba(0,0,0,0.15);
    }
    
    
    .select2-container--default .select2-selection--single {
        border-color: #ced4da !important;
    }
    .select2-container--bootstrap-5 {
        width: 100% !important;
    }

    
    @media (max-width: 768px) {
        .item-card {
            flex-direction: column;
            text-align: center;
        }
        .item-image {
            width: 100%;
            height: auto;
            margin-bottom: 15px;
        }
        .d-flex.justify-content-end {
            justify-content: center !important;
        }

        form.d-flex {
            flex-direction: column;
            gap: 10px;
        }
        .input-group.w-50 {
            width: 100% !important;
        }
        .form-select.w-auto {
            width: 100% !important;
        }

        .fab {
            bottom: 15px;
            right: 15px;
            width: 45px;
            height: 45px;
            font-size: 28px;
            line-height: 45px;
        }
        
        
        #darkModeToggle {
            margin-left: 10px;
        }
    }
</style>

</head>
<body>
    
<div class="container py-4">

    <div class="row mb-4">
        <div class="col-12">
            
            <div class="d-flex align-items-center mb-3">
                <h1 class="mb-0">My Collection Manager</h1>
                <button id="darkModeToggle">☀️</button>
            </div>
            <form method="GET" class="d-flex justify-content-between align-items-center">
                <div class="input-group w-50 me-3">
                    <span class="input-group-text bg-white border-end-0">🔍</span>
                    <input type="text" name="search" class="form-control border-start-0"
                     placeholder="Search items..." value="<?php echo $_GET['search'] ?? '' ?>">
                </div>

                <select name="tag" class="form-select w-auto" onchange="this.form.submit()">
                   <option value="">All Tags</option>
                        <?php 
                        $tag_query = $conn->query("SELECT * FROM tags");
                        while($t = $tag_query->fetch_assoc()){
                        $selected = ($_GET['tag'] ?? '') == $t['id'] ? "selected" : "";
                        echo "<option value='{$t['id']}' $selected>{$t['tag_name']}</option>";
                       }
                        ?>
                </select>
            </form>
        </div>
      </div>

    <div class="row g-3" id="collection-list">
        <?php
            
            $where = "WHERE 1";
            if(!empty($_GET['search'])) {
                $s = $conn->real_escape_string($_GET['search']);
                $where .= " AND (title LIKE '%$s%' OR description LIKE '%$s%')";
            }

            if (!empty($_GET['tag'])) {
                $tag_id = $conn->real_escape_string($_GET['tag']);
                $where .= " AND tag_id = '$tag_id'";
            }

            
            $items = $conn->query("SELECT items.*, tags.tag_name 
                                          FROM items 
                                          JOIN tags ON items.tag_id = tags.id 
                                          $where 
                                          ORDER BY items.id ASC"); 
            if($items->num_rows > 0){
                while($row = $items->fetch_assoc()){
                    
                    $data_attrs = "data-id='{$row['id']}' 
                                         data-title='{$row['title']}' 
                                         data-description='{$row['description']}' 
                                         data-tag-id='{$row['tag_id']}' 
                                         data-image='{$row['image_url']}'
                                         data-link='{$row['link_url']}'";
                    
                    
                    $actual_link = trim($row['link_url']);
                    $link_href = !empty($actual_link) ? $actual_link : 'javascript:void(0);';
                    $is_link_present = !empty($actual_link) ? 'true' : 'false';
                    $disabled_style = ($is_link_present == 'false') ? 'style="opacity: 0.6; cursor: not-allowed;"' : '';
                    
                    echo "
                    <div class='col-12' id='item-{$row['id']}'>
                        <div class='d-flex bg-white p-3 shadow-sm item-card'>
                            <img src='{$row['image_url']}' class='img-fluid me-3 item-image'>
                            <div class='flex-grow-1'>
                                <div class='d-flex justify-content-between align-items-start'>
                                    <h5 class='mb-1'>{$row['title']}</h5>
                                    <span class='badge bg-primary text-white'>{$row['tag_name']}</span>
                                </div>
                                <p class='text-muted mb-3'>{$row['description']}</p>
                                <div class='d-flex justify-content-end align-items-center'>
                                    
                                    <a href='{$link_href}' 
                                        target='_blank' 
                                        class='btn btn-outline-secondary btn-sm me-2 visit-btn-long visit-link'
                                        data-link-present='{$is_link_present}'
                                        data-title='{$row['title']}'
                                        {$disabled_style}
                                    >
                                        Visit
                                    </a>
                                    
                                    <button class='btn btn-outline-secondary btn-sm me-1 edit-btn' data-bs-toggle='modal' data-bs-target='#editItemModal' $data_attrs>✏️</button>
                                    
                                    <button class='btn btn-outline-danger btn-sm delete-btn' data-id='{$row['id']}' data-title='{$row['title']}'>🗑️</button>
                                </div>
                            </div>
                        </div>
                    </div>
                    ";
                }
            } else {
                echo "<p class='text-center text-danger'>No items found</p>";
            }
        ?>
    </div>
</div>

<button class="btn btn-primary fab" data-bs-toggle="modal" data-bs-target="#addItemModal">+</button>

    
<div class="modal fade" id="addItemModal" tabindex="-1">
  <div class="modal-dialog">
    <div class="modal-content">
      
      <form method="POST" action="save_item.php" id="addItemForm">

        <div class="modal-header">
          <h5 class="modal-title">Add New Item</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
        </div>

           <p class="text-muted px-3">Add a new item to your collection. Fill in the details below.</p>

        <div class="modal-body">

            <div class="mb-3">
                <label class="form-label">Title *</label>
                <input type="text" name="title" class="form-control border-dark mb-2" placeholder="Enter item title" required maxlength="500">
            </div>
            
            <div class="mb-3">
                <label class="form-label">Description *</label>
                <textarea name="description" class="form-control border-dark mb-2" placeholder="Enter Description" required maxlength="300"></textarea>
            </div>

            <div class="mb-3">
                <label class="form-label">Tag *</label>
                <select name="tag_id" id="add_tag_id" class="form-control border-dark mb-2" required>
                    <option value="">--- Select ---</option>
                    <?php
                        foreach($all_tags as $t){
                            echo "<option value='{$t['id']}'>{$t['tag_name']}</option>";
                        }
                    ?>
                </select>
            </div>

            <div class="mb-3">
                <label class="form-label">Image URL</label>
                <input type="url" name="image_url" class="form-control border-dark mb-2" placeholder="https://example.com/image.jpg">
            </div>
            <p class="text-muted px-3">Optional. A default image will be used if left empty.</p>

            <div class="mb-3">
                <label class="form-label">Website Link</label>
                <input type="url" name="link_url" class="form-control border-dark mb-2" placeholder="https://example.com">
            </div>
            <p class="text-muted px-3">Optional. Add a related URL for this item.</p>

        </div>

        <div class="modal-footer">
          <button type="submit" class="btn btn-primary">Add Item</button>
          <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
        </div>

      </form>

    </div>
  </div>
</div>
    

<div class="modal fade" id="editItemModal" tabindex="-1">
  <div class="modal-dialog">
    <div class="modal-content">
      
      <form id="editForm">
            <input type="hidden" name="id" id="edit_id">

        <div class="modal-header">
          <h5 class="modal-title">Edit Item</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
        </div>

        <div class="modal-body">

            <div class="mb-3">
                <label class="form-label">Title *</label>
                <input type="text" name="title" id="edit_title" class="form-control border-dark mb-2" required maxlength="500">
            </div>

            <div class="mb-3">
                <label class="form-label">Description *</label>
                <textarea name="description" id="edit_description" class="form-control border-dark mb-2" required maxlength="300"></textarea>
            </div>

            <div class="mb-3">
                <label class="form-label">Tag *</label>
                <select name="tag_id" id="edit_tag_id" class="form-control border-dark mb-2" required>
                    <option value="">--- Select ---</option>
                    <?php
                        foreach($all_tags as $t){
                            echo "<option value='{$t['id']}'>{$t['tag_name']}</option>";
                        }
                    ?>
                </select>
            </div>

            <div class="mb-3">
                <label class="form-label">Image URL</label>
                <input type="url" name="image_url" id="edit_image" class="form-control border-dark mb-2">
            </div>

            <div class="mb-3">
                <label class="form-label">Website Link</label>
                <input type="url" name="link_url" id="edit_link" class="form-control border-dark mb-2">
            </div>

        </div>

        <div class="modal-footer">
          <button type="submit" class="btn btn-primary">Save Changes</button>
          <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
          
        </div>

      </form>

    </div>
  </div>
</div>


<script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>

<script>
$(document).ready(function() {
    
    function showAlert(message, type) {
        console.log(type.toUpperCase() + ": " + message);
        alert(type.toUpperCase() + ": " + message);
    }
    
    
    const toggleButton = $('#darkModeToggle');
    const body = $('body');

    
    function applyTheme(theme) {
        if (theme === 'dark') {
            body.addClass('dark-mode');
            toggleButton.html('🌙');
            localStorage.setItem('theme', 'dark');
        } else {
            body.removeClass('dark-mode');
            toggleButton.html('☀️');
            localStorage.setItem('theme', 'light');
        }
    }

    
    const savedTheme = localStorage.getItem('theme') || (window.matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light');
    applyTheme(savedTheme);

    toggleButton.on('click', function() {
        const currentTheme = body.hasClass('dark-mode') ? 'dark' : 'light';
        const newTheme = currentTheme === 'light' ? 'dark' : 'light';
        applyTheme(newTheme);
    });

    $('#edit_tag_id').select2({
        dropdownParent: $('#editItemModal')
    });
    
    $('#add_tag_id').select2({
        dropdownParent: $('#addItemModal')
    });


    $('.edit-btn').on('click', function() {
        const item = $(this).data(); 

        $('#edit_id').val(item.id);
        $('#edit_title').val(item.title);
        $('#edit_description').val(item.description);
        
        
        $('#edit_tag_id').val(item.tagId).trigger('change'); 
        
        $('#edit_image').val(item.image); 
        $('#edit_link').val(item.link); 
    });

    
    
    $('#addItemForm').on('submit', function(e) {
        e.preventDefault(); 

        const formData = $(this).serialize();

        $.ajax({
            type: "POST",
            url: "save_item.php", 
            data: formData,
            dataType: "json",
            success: function(response) {
                $('#addItemModal').modal('hide');
                showAlert(response.message, response.status);
                
                if (response.status === "success") {
                    
                    location.reload(); 
                }
            },
            error: function(xhr, status, error) {
                $('#addItemModal').modal('hide');
                showAlert("Add Item failed: Could not connect to the server or process data.", "error");
            }
        });
    });

    
    
    $('#editForm').on('submit', function(e) {
        e.preventDefault(); 

        const formData = $(this).serialize();

        $.ajax({
            type: "POST",
            url: "api/update_item.php", 
            data: formData,
            dataType: "json",
            success: function(response) {
                $('#editItemModal').modal('hide');
                showAlert(response.message, response.status);
                if (response.status === "success") {
                    location.reload(); 
                }
            },
            error: function(xhr, status, error) {
                $('#editItemModal').modal('hide');
                showAlert("Update failed: Could not connect to the server or parse response.", "error");
            }
        });
    });

    
    $('.delete-btn').on('click', function() {
        const id = $(this).data('id');
        const title = $(this).data('title');

        if (confirm(`Are you sure you want to delete "${title}"?`)) {
            $.ajax({
                type: "POST",
                url: "api/delete_item.php", 
                data: { id: id },
                dataType: "json",
                success: function(response) {
                    showAlert(response.message, response.status);
                    if (response.status === "success") {
                        $('#item-' + id).remove();
                    }
                },
                error: function(xhr, status, error) {
                    showAlert("Delete failed: Could not connect to the server or parse response.", "error");
                }
            });
        }
    });

    $('.visit-link').on('click', function(e) {
        
        const isPresent = $(this).data('link-present');
        const title = $(this).data('title');
        
        
        if (isPresent === 'false') {
            e.preventDefault(); 
            
            
            showAlert(`No Link Provided: The item "${title}" does not have a website link saved.`, "error");
            
            return false;
        }
        
    });
    
});
</script>

</body>
</html>