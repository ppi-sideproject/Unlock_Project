<?php
include "config.php";

header("Content-Type: application/json");


if ($_SERVER['REQUEST_METHOD'] === 'POST' && $_GET['action'] === 'add') {

    $title = $_POST['title'] ?? '';
    $description = $_POST['description'] ?? '';
    $tag_id = $_POST['tag_id'] ?? '';
    $image_url = $_POST['image_url'] ?? '';
    $link_url = $_POST['link_url'] ?? '';

    if ($image_url == "") {
        $image_url = "https://via.placeholder.com/150?text=No+Image";
    }

    $query = "INSERT INTO items (title, description, image_url, link_url, tag_id) 
              VALUES ('$title', '$description', '$image_url', '$link_url', '$tag_id')";

    if (mysqli_query($conn, $query)) {
        echo json_encode(["status" => "success", "message" => "Item added successfully"]);
    } else {
        echo json_encode(["status" => "error", "message" => "Failed to add item"]);
    }
    exit;
}



if ($_SERVER['REQUEST_METHOD'] === 'POST' && $_GET['action'] === 'update') {

    $id = $_POST['id'];
    $title = $_POST['title'];
    $description = $_POST['description'];
    $tag_id = $_POST['tag_id'];
    $image_url = $_POST['image_url'];
    $link_url = $_POST['link_url'];

    $query = "UPDATE items SET 
                title='$title', 
                description='$description',
                image_url='$image_url',
                link_url='$link_url',
                tag_id='$tag_id'
              WHERE id='$id'";

    if (mysqli_query($conn, $query)) {
        echo json_encode(["status" => "success", "message" => "Item updated successfully"]);
    } else {
        echo json_encode(["status" => "error", "message" => "Failed to update item"]);
    }
    exit;
}



if ($_SERVER['REQUEST_METHOD'] === 'GET' && $_GET['action'] === 'delete') {

    $id = $_GET['id'];

    $query = "DELETE FROM items WHERE id='$id'";

    if (mysqli_query($conn, $query)) {
        echo json_encode(["status" => "success", "message" => "Item deleted"]);
    } else {
        echo json_encode(["status" => "error", "message" => "Failed to delete item"]);
    }
    exit;
}



if ($_SERVER['REQUEST_METHOD'] === 'GET' && $_GET['action'] === 'getAll') {

    $result = mysqli_query($conn, 
        "SELECT items.*, tags.tag_name 
         FROM items 
         JOIN tags ON items.tag_id = tags.id"
    );

    $data = [];
    while ($row = mysqli_fetch_assoc($result)) {
        $data[] = $row;
    }

    echo json_encode($data);
    exit;
}



if ($_SERVER['REQUEST_METHOD'] === 'GET' && $_GET['action'] === 'search') {

    $term = $_GET['term'];
    $tag = $_GET['tag'] ?? '';

    $query = "SELECT items.*, tags.tag_name FROM items 
              JOIN tags ON items.tag_id = tags.id
              WHERE (title LIKE '%$term%' OR description LIKE '%$term%')";

    if ($tag != "") {
        $query .= " AND tag_id='$tag'";
    }

    $result = mysqli_query($conn, $query);

    $data = [];
    while ($row = mysqli_fetch_assoc($result)) {
        $data[] = $row;
    }

    echo json_encode($data);
    exit;
}

echo json_encode(["status" => "error", "message" => "Invalid API Request"]);
?>